package com.example.vocales;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    MediaPlayer mp;
    Button btnsonidoa;
    Button btnsonidoe;
    Button btnsonidoi;
    Button btnsonidoo;
    Button btnsonidou;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btnsonidoa = (Button)findViewById(R.id.btnsonidoa);
        mp = MediaPlayer.create(this, R.raw.a);
        btnsonidoa.setOnClickListener(v -> mp.start());
        btnsonidoe = (Button)findViewById(R.id.btnsonidoe);
        mp = MediaPlayer.create(this, R.raw.e);
        btnsonidoe.setOnClickListener(view -> mp.start());
        btnsonidoi = (Button)findViewById(R.id.btnsonidoi);
        mp = MediaPlayer.create(this, R.raw.i);
        btnsonidoi.setOnClickListener(view -> mp.start());
        btnsonidoo = (Button)findViewById(R.id.btnsonidoo);
        mp = MediaPlayer.create(this, R.raw.o);
        btnsonidoo.setOnClickListener(view -> mp.start());
        btnsonidou = (Button)findViewById(R.id.btnsonidou);
        mp = MediaPlayer.create(this, R.raw.u);
        btnsonidou.setOnClickListener(view -> mp.start());

    }
}